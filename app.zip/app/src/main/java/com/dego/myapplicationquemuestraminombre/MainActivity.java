package com.dego.myapplicationquemuestraminombre;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        TextView mensajeTextView;
        EditText mensajeEditText;


    public void buttonPress(View view ){

         Log.i("Info","BotonPrecionado");

        mensajeEditText = findViewById(R.id.mensajeEditText);

        String mensajeString = mensajeEditText.getText().toString();
        mensajeTextView.setText(mensajeString);

        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mensajeTextView = findViewById(R.id.mensajeTextView);
        mensajeTextView.setText("Hola Diego");
    }
}